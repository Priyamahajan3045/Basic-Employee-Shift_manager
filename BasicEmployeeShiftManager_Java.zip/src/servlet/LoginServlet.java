package servlet;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import db.DBConnection;

public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String email = req.getParameter("email");
        String pass = req.getParameter("password");

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement("SELECT * FROM users WHERE email=? AND password=?");
            pst.setString(1, email);
            pst.setString(2, pass);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                HttpSession session = req.getSession();
                session.setAttribute("uid", rs.getInt("id"));
                session.setAttribute("name", rs.getString("name"));
                res.sendRedirect("dashboard.jsp");
            } else {
                res.getWriter().print("Invalid Credentials");
            }
        } catch (Exception e) {
            res.getWriter().print("Error: " + e.getMessage());
        }
    }
}