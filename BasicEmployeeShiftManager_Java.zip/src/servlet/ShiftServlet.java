package servlet;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import db.DBConnection;

public class ShiftServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int uid = Integer.parseInt(req.getParameter("uid"));
        String start = req.getParameter("start");
        String end = req.getParameter("end");

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement pst = con.prepareStatement("INSERT INTO shifts (user_id, start_time, end_time) VALUES (?, ?, ?)");
            pst.setInt(1, uid);
            pst.setString(2, start);
            pst.setString(3, end);
            pst.executeUpdate();
            res.sendRedirect("dashboard.jsp");
        } catch (Exception e) {
            res.getWriter().print("Error: " + e.getMessage());
        }
    }
}